import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ChevronRight, i as Power, n as Settings2, o as ChevronLeft, r as ScrollText, s as Check } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { r as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BBBaMJpk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatDuration(totalSeconds) {
	const h = Math.floor(totalSeconds / 3600);
	const m = Math.floor(totalSeconds % 3600 / 60);
	const s = totalSeconds % 60;
	const pad = (n) => n.toString().padStart(2, "0");
	return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes.toFixed(0)} B`;
	if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
	if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
	return `${(bytes / 1073741824).toFixed(2)} GB`;
}
function formatMbps(bytesPerSec) {
	const mbps = bytesPerSec * 8 / 1e6;
	if (mbps < .1) return `${(mbps * 1e3).toFixed(0)} Kbps`;
	return `${mbps.toFixed(1)} Mbps`;
}
function ConnectOrb({ status, onToggle, label }) {
	const live = status === "connected";
	const busy = status === "connecting";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onToggle,
		"aria-label": label,
		"aria-pressed": live,
		className: cn("relative mx-auto grid size-44 place-items-center rounded-full outline-none", "transition-transform duration-150 ease-out active:scale-[0.96]", "focus-visible:ring-2 focus-visible:ring-accent/70"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 176 176",
			className: cn("absolute inset-0 size-full", live && "orb-live"),
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "88",
					cy: "88",
					r: "82",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1",
					className: "text-border"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "88",
					cy: "88",
					r: "70",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.5",
					className: cn(live ? "text-connected/40" : "text-border")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "88",
					cy: "88",
					r: "70",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "3",
					strokeLinecap: "round",
					strokeDasharray: busy ? "44 400" : live ? "440 0" : "0 440",
					className: cn("text-accent transition-[stroke-dasharray] duration-500", live && "text-connected", busy && "orb-spin text-accent")
				}),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "88",
					cy: "88",
					r: "58",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1",
					className: "orb-pulse text-accent/50"
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative grid size-24 place-items-center rounded-full border border-border bg-surface", "transition-colors duration-200", live && "border-connected/40 bg-elevated"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, {
				className: cn("size-8 transition-colors duration-200", live ? "text-connected" : "text-fg", busy && "opacity-70"),
				strokeWidth: 1.75
			})
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[opacity,transform,background-color,color] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated",
			subtle: "bg-elevated text-fg hover:bg-elevated/80"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-lg px-4 text-sm",
			lg: "h-12 rounded-xl px-5 text-base",
			icon: "size-11 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var COPY = {
	fa: {
		appName: "سورن",
		tagline: "اتصال امن، یک لمس",
		disconnected: "قطع است",
		connecting: "در حال برقراری تونل…",
		connected: "متصل — رمزنگاری فعال",
		tapToConnect: "برای اتصال لمس کنید",
		tapToDisconnect: "برای قطع، دوباره لمس کنید",
		connectingHint: "دست‌دهی امن در جریان است",
		session: "مدت نشست",
		virtualIp: "آدرس مجازی",
		download: "دریافت",
		upload: "ارسال",
		ping: "پینگ",
		location: "موقعیت",
		protocol: "پروتکل",
		locationsTitle: "موقعیت‌ها",
		locationsSub: "یک نقطهٔ خروجی انتخاب کنید",
		settingsTitle: "تنظیمات",
		logsTitle: "گزارش اتصال",
		logsEmpty: "هنوز گزارشی ثبت نشده.",
		autoReconnect: "اتصال مجدد خودکار",
		autoReconnectHint: "اگر پیوند قطع شود دوباره تلاش می‌کند",
		killSwitch: "قطع اضطراری",
		killSwitchHint: "نمایشی — در این کلاینت ترافیک واقعی مسدود نمی‌شود",
		language: "زبان",
		languageFa: "فارسی",
		languageEn: "English",
		about: "درباره",
		aboutBody: "سورن یک کلاینت نمایشی است. مرورگر نمی‌تواند VPN سطح سیستم بسازد یا فیلتر اینترنت را دور بزند. هیچ ترافیکی از دستگاه شما تونل نمی‌شود.",
		homeNote: "نمایشی — ترافیک دستگاه تونل نمی‌شود",
		introTitle: "قبل از شروع",
		introBody: "سورن ظاهر و حس یک کلاینت VPN یک‌لمسی را شبیه‌سازی می‌کند. اتصال، سرورها و آمار همگی نمایشی‌اند — ترافیک واقعی دستگاه جابه‌جا نمی‌شود و فیلترشکن واقعی نیست.",
		introCta: "متوجه شدم",
		back: "بازگشت",
		bestServer: "بهترین سرور",
		load: "بار",
		ms: "ms",
		protocolWireguard: "WireGuard",
		protocolOpenvpn: "OpenVPN",
		protocolIkev2: "IKEv2",
		countryAuto: "هوشمند",
		countryDe: "آلمان",
		countryNl: "هلند",
		countryTr: "ترکیه",
		countryAe: "امارات",
		countrySe: "سوئد",
		countryGb: "بریتانیا",
		countryFr: "فرانسه",
		countryUs: "آمریکا",
		countryCa: "کانادا",
		countryJp: "ژاپن",
		countrySg: "سنگاپور",
		cityAuto: "کم‌ترین تأخیر",
		cityFra: "فرانکفورت",
		cityAms: "آمستردام",
		cityIst: "استانبول",
		cityDxb: "دبی",
		citySto: "استکهلم",
		cityLon: "لندن",
		cityPar: "پاریس",
		cityNyc: "نیویورک",
		cityTor: "تورنتو",
		cityTyo: "توکیو",
		citySin: "سنگاپور",
		logResolve: "در حال یافتن نقطهٔ خروجی",
		logChannel: "گشودن کانال رمزنگاری‌شده",
		logHandshake: "دست‌دهی پروتکل",
		logAddress: "اختصاص آدرس مجازی",
		logRoute: "نصب مسیر نمایشی",
		logUp: "تونل نمایشی برقرار شد",
		logDown: "تونل بسته شد",
		logCancel: "اتصال لغو شد",
		clearLogs: "پاک کردن گزارش"
	},
	en: {
		appName: "Soren",
		tagline: "Secure link, one tap",
		disconnected: "Disconnected",
		connecting: "Establishing tunnel…",
		connected: "Connected — encryption on",
		tapToConnect: "Tap to connect",
		tapToDisconnect: "Tap again to disconnect",
		connectingHint: "Secure handshake in progress",
		session: "Session",
		virtualIp: "Virtual address",
		download: "Down",
		upload: "Up",
		ping: "Ping",
		location: "Location",
		protocol: "Protocol",
		locationsTitle: "Locations",
		locationsSub: "Choose an exit node",
		settingsTitle: "Settings",
		logsTitle: "Connection log",
		logsEmpty: "No events yet.",
		autoReconnect: "Auto reconnect",
		autoReconnectHint: "Retry if the link drops",
		killSwitch: "Kill switch",
		killSwitchHint: "Demo only — real traffic is not blocked here",
		language: "Language",
		languageFa: "فارسی",
		languageEn: "English",
		about: "About",
		aboutBody: "Soren is a simulated client. A browser cannot create a system VPN or bypass network filters. None of your device traffic is tunneled.",
		homeNote: "Demo — device traffic is not tunneled",
		introTitle: "Before you start",
		introBody: "Soren recreates the feel of a one-tap VPN client. Connections, servers, and stats are simulated — your device traffic is not routed, and this is not a real circumvention tool.",
		introCta: "Got it",
		back: "Back",
		bestServer: "Fastest",
		load: "Load",
		ms: "ms",
		protocolWireguard: "WireGuard",
		protocolOpenvpn: "OpenVPN",
		protocolIkev2: "IKEv2",
		countryAuto: "Smart",
		countryDe: "Germany",
		countryNl: "Netherlands",
		countryTr: "Turkey",
		countryAe: "UAE",
		countrySe: "Sweden",
		countryGb: "United Kingdom",
		countryFr: "France",
		countryUs: "United States",
		countryCa: "Canada",
		countryJp: "Japan",
		countrySg: "Singapore",
		cityAuto: "Lowest latency",
		cityFra: "Frankfurt",
		cityAms: "Amsterdam",
		cityIst: "Istanbul",
		cityDxb: "Dubai",
		citySto: "Stockholm",
		cityLon: "London",
		cityPar: "Paris",
		cityNyc: "New York",
		cityTor: "Toronto",
		cityTyo: "Tokyo",
		citySin: "Singapore",
		logResolve: "Resolving exit node",
		logChannel: "Opening encrypted channel",
		logHandshake: "Protocol handshake",
		logAddress: "Assigning virtual address",
		logRoute: "Installing demo route",
		logUp: "Demo tunnel is up",
		logDown: "Tunnel closed",
		logCancel: "Connection cancelled",
		clearLogs: "Clear log"
	}
};
function t(lang, key) {
	return COPY[lang][key];
}
function protocolLabel(lang, id) {
	if (id === "openvpn") return t(lang, "protocolOpenvpn");
	if (id === "ikev2") return t(lang, "protocolIkev2");
	return t(lang, "protocolWireguard");
}
var SERVERS = [
	{
		id: "auto",
		cityKey: "cityAuto",
		countryKey: "countryAuto",
		code: "AUTO",
		ping: 22,
		load: 18,
		ipPrefix: "185.230"
	},
	{
		id: "de-fra",
		cityKey: "cityFra",
		countryKey: "countryDe",
		code: "DE",
		ping: 28,
		load: 24,
		ipPrefix: "185.244"
	},
	{
		id: "nl-ams",
		cityKey: "cityAms",
		countryKey: "countryNl",
		code: "NL",
		ping: 31,
		load: 21,
		ipPrefix: "45.139"
	},
	{
		id: "tr-ist",
		cityKey: "cityIst",
		countryKey: "countryTr",
		code: "TR",
		ping: 36,
		load: 33,
		ipPrefix: "77.92"
	},
	{
		id: "ae-dxb",
		cityKey: "cityDxb",
		countryKey: "countryAe",
		code: "AE",
		ping: 42,
		load: 29,
		ipPrefix: "94.205"
	},
	{
		id: "se-sto",
		cityKey: "citySto",
		countryKey: "countrySe",
		code: "SE",
		ping: 39,
		load: 16,
		ipPrefix: "185.213"
	},
	{
		id: "gb-lon",
		cityKey: "cityLon",
		countryKey: "countryGb",
		code: "GB",
		ping: 44,
		load: 38,
		ipPrefix: "51.89"
	},
	{
		id: "fr-par",
		cityKey: "cityPar",
		countryKey: "countryFr",
		code: "FR",
		ping: 41,
		load: 27,
		ipPrefix: "51.158"
	},
	{
		id: "us-nyc",
		cityKey: "cityNyc",
		countryKey: "countryUs",
		code: "US",
		ping: 78,
		load: 44,
		ipPrefix: "104.21"
	},
	{
		id: "ca-tor",
		cityKey: "cityTor",
		countryKey: "countryCa",
		code: "CA",
		ping: 82,
		load: 31,
		ipPrefix: "142.147"
	},
	{
		id: "jp-tyo",
		cityKey: "cityTyo",
		countryKey: "countryJp",
		code: "JP",
		ping: 91,
		load: 22,
		ipPrefix: "103.137"
	},
	{
		id: "sg-sin",
		cityKey: "citySin",
		countryKey: "countrySg",
		code: "SG",
		ping: 88,
		load: 19,
		ipPrefix: "103.28"
	}
];
function getServer(id) {
	return SERVERS.find((s) => s.id === id) ?? SERVERS[0];
}
function pickFastest() {
	return SERVERS.filter((s) => s.id !== "auto").reduce((best, cur) => cur.ping < best.ping ? cur : best);
}
function allocateVirtualIp(prefix) {
	return `${prefix}.${12 + Math.floor(Math.random() * 200)}.${4 + Math.floor(Math.random() * 250)}`;
}
var connectGen = 0;
var timeouts = [];
var tickId = null;
function clearTimeouts() {
	for (const id of timeouts) window.clearTimeout(id);
	timeouts.length = 0;
}
function stopTick() {
	if (tickId != null) {
		window.clearInterval(tickId);
		tickId = null;
	}
}
function pushLog(textKey, detail) {
	return {
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
		at: Date.now(),
		textKey,
		detail
	};
}
var useVpnStore = create()(persist((set, get) => ({
	status: "disconnected",
	selectedServerId: "auto",
	protocol: "wireguard",
	autoReconnect: true,
	killSwitch: false,
	language: "fa",
	sessionStartedAt: null,
	bytesUp: 0,
	bytesDown: 0,
	rateUp: 0,
	rateDown: 0,
	virtualIp: null,
	logs: [],
	hasSeenIntro: false,
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	setLanguage: (language) => set({ language }),
	setProtocol: (protocol) => set({ protocol }),
	setSelectedServer: (id) => {
		const { status } = get();
		set({ selectedServerId: id });
		if (status === "connected") get().disconnect("stop");
	},
	setAutoReconnect: (value) => set({ autoReconnect: value }),
	setKillSwitch: (value) => set({ killSwitch: value }),
	setHasSeenIntro: () => set({ hasSeenIntro: true }),
	clearLogs: () => set({ logs: [] }),
	disconnect: (reason = "stop") => {
		connectGen += 1;
		clearTimeouts();
		stopTick();
		const key = reason === "cancel" ? "logCancel" : "logDown";
		set((s) => ({
			status: "disconnected",
			sessionStartedAt: null,
			bytesUp: 0,
			bytesDown: 0,
			rateUp: 0,
			rateDown: 0,
			virtualIp: null,
			logs: [pushLog(key), ...s.logs].slice(0, 80)
		}));
	},
	toggleConnection: () => {
		const { status } = get();
		if (status === "connecting") {
			get().disconnect("cancel");
			return;
		}
		if (status === "connected") {
			get().disconnect("stop");
			return;
		}
		const gen = ++connectGen;
		const server = getServer(get().selectedServerId);
		const endpoint = server.id === "auto" ? pickFastest() : server;
		const protocol = get().protocol;
		set((s) => ({
			status: "connecting",
			logs: [pushLog("logResolve", endpoint.code), ...s.logs].slice(0, 80)
		}));
		const steps = [
			{
				delay: 520,
				apply: () => set((s) => ({ logs: [pushLog("logChannel"), ...s.logs].slice(0, 80) }))
			},
			{
				delay: 1100,
				apply: () => set((s) => ({ logs: [pushLog("logHandshake", protocol), ...s.logs].slice(0, 80) }))
			},
			{
				delay: 1680,
				apply: () => set((s) => ({ logs: [pushLog("logAddress"), ...s.logs].slice(0, 80) }))
			},
			{
				delay: 2280,
				apply: () => {
					const ip = allocateVirtualIp(endpoint.ipPrefix);
					set((s) => ({
						status: "connected",
						sessionStartedAt: Date.now(),
						virtualIp: ip,
						logs: [
							pushLog("logUp", ip),
							pushLog("logRoute"),
							...s.logs
						].slice(0, 80)
					}));
					stopTick();
					tickId = window.setInterval(() => {
						if (get().status !== "connected") return;
						const down = 18e3 + Math.random() * 42e4;
						const up = 6e3 + Math.random() * 9e4;
						set((s) => ({
							bytesDown: s.bytesDown + down,
							bytesUp: s.bytesUp + up,
							rateDown: down,
							rateUp: up
						}));
					}, 1e3);
				}
			}
		];
		for (const step of steps) {
			const id = window.setTimeout(() => {
				if (connectGen !== gen) return;
				step.apply();
			}, step.delay);
			timeouts.push(id);
		}
	}
}), {
	name: "soren-vpn",
	skipHydration: true,
	partialize: (s) => ({
		selectedServerId: s.selectedServerId,
		protocol: s.protocol,
		autoReconnect: s.autoReconnect,
		killSwitch: s.killSwitch,
		language: s.language,
		hasSeenIntro: s.hasSeenIntro
	})
}));
function IntroSheet() {
	const language = useVpnStore((s) => s.language);
	const setHasSeenIntro = useVpnStore((s) => s.setHasSeenIntro);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex items-end bg-bg/70 panel-enter",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full rounded-t-2xl border border-border bg-surface p-5 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1 w-10 rounded-full bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium leading-snug",
					children: t(language, "introTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-normal text-muted",
					children: t(language, "introBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					className: "mt-5 w-full",
					onClick: setHasSeenIntro,
					children: t(language, "introCta")
				})
			]
		})
	});
}
function PanelHeader({ title, subtitle, onBack, backLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-3 px-4 pt-4 pb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			size: "icon",
			onClick: onBack,
			"aria-label": backLabel,
			className: "shrink-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 rtl:rotate-0 ltr:rotate-180" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-medium leading-snug",
				children: title
			}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted leading-snug",
				children: subtitle
			}) : null]
		})]
	});
}
function LocationsPanel({ onBack }) {
	const language = useVpnStore((s) => s.language);
	const selected = useVpnStore((s) => s.selectedServerId);
	const setSelectedServer = useVpnStore((s) => s.setSelectedServer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-20 flex flex-col bg-bg panel-enter",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHeader, {
			title: t(language, "locationsTitle"),
			subtitle: t(language, "locationsSub"),
			onBack,
			backLabel: t(language, "back")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: SERVERS.map((server) => {
					const active = server.id === selected;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setSelectedServer(server.id);
							onBack();
						},
						className: cn("flex w-full items-center gap-3 rounded-xl border px-3 py-3 text-start", "transition-[background-color,border-color] duration-150 ease-out", active ? "border-accent/40 bg-elevated" : "border-border bg-surface hover:bg-elevated"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-lg bg-elevated text-xs font-medium tracking-wide text-accent",
								children: server.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-medium",
									children: t(language, server.cityKey)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm text-muted",
									children: t(language, server.countryKey)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex shrink-0 flex-col items-end gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-sm text-fg",
									children: [server.ping, t(language, "ms")]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted tabular-nums",
									children: [
										t(language, "load"),
										" ",
										server.load,
										"%"
									]
								})]
							}),
							active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-4 shrink-0 text-connected",
								strokeWidth: 2
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-4 shrink-0" })
						]
					}) }, server.id);
				})
			})
		})]
	});
}
function LogsPanel({ onBack }) {
	const language = useVpnStore((s) => s.language);
	const logs = useVpnStore((s) => s.logs);
	const clearLogs = useVpnStore((s) => s.clearLogs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-20 flex flex-col bg-bg panel-enter",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHeader, {
			title: t(language, "logsTitle"),
			onBack,
			backLabel: t(language, "back")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-6",
			children: [logs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 py-8 text-sm text-muted",
				children: t(language, "logsEmpty")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: logs.map((line) => {
					const time = new Date(line.at).toLocaleTimeString(language === "fa" ? "fa-IR" : "en-GB", {
						hour: "2-digit",
						minute: "2-digit",
						second: "2-digit"
					});
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-border bg-surface px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tabular-nums text-muted",
							children: time
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [t(language, line.textKey), line.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [" · ", line.detail]
							}) : null]
						})]
					}, line.id);
				})
			}), logs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					className: "w-full",
					onClick: clearLogs,
					children: t(language, "clearLogs")
				})
			}) : null]
		})]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("inline-flex h-7 w-12 shrink-0 items-center rounded-full border border-border bg-elevated p-0.5 transition-[background-color] duration-150 ease-out data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 rounded-full bg-muted transition-[transform,background-color] duration-150 ease-out data-[state=checked]:translate-x-5 data-[state=checked]:bg-accent-fg" })
	});
}
var PROTOCOLS = [
	"wireguard",
	"openvpn",
	"ikev2"
];
function SettingsPanel({ onBack }) {
	const language = useVpnStore((s) => s.language);
	const protocol = useVpnStore((s) => s.protocol);
	const autoReconnect = useVpnStore((s) => s.autoReconnect);
	const killSwitch = useVpnStore((s) => s.killSwitch);
	const setLanguage = useVpnStore((s) => s.setLanguage);
	const setProtocol = useVpnStore((s) => s.setProtocol);
	const setAutoReconnect = useVpnStore((s) => s.setAutoReconnect);
	const setKillSwitch = useVpnStore((s) => s.setKillSwitch);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-20 flex flex-col bg-bg panel-enter",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHeader, {
			title: t(language, "settingsTitle"),
			onBack,
			backLabel: t(language, "back")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: t(language, "autoReconnect")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(language, "autoReconnectHint")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: autoReconnect,
								onCheckedChange: setAutoReconnect,
								"aria-label": t(language, "autoReconnect")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: t(language, "killSwitch")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(language, "killSwitchHint")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: killSwitch,
								onCheckedChange: setKillSwitch,
								"aria-label": t(language, "killSwitch")
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 mb-2 px-1 text-xs font-medium tracking-wide text-muted",
					children: t(language, "protocol")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2 rounded-2xl border border-border bg-surface p-2",
					children: PROTOCOLS.map((id) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setProtocol(id),
							className: cn("h-10 rounded-lg text-sm font-medium transition-colors duration-150", protocol === id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
							children: protocolLabel(language, id)
						}, id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 mb-2 px-1 text-xs font-medium tracking-wide text-muted",
					children: t(language, "language")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 rounded-2xl border border-border bg-surface p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLanguage("fa"),
						className: cn("h-10 rounded-lg text-sm font-medium transition-colors duration-150", language === "fa" ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
						children: t(language, "languageFa")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLanguage("en"),
						className: cn("h-10 rounded-lg text-sm font-medium transition-colors duration-150", language === "en" ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
						children: t(language, "languageEn")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6 rounded-2xl border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: t(language, "about")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-normal text-muted",
						children: t(language, "aboutBody")
					})]
				})
			]
		})]
	});
}
function HomeView() {
	const [panel, setPanel] = (0, import_react.useState)("none");
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const hydrated = useVpnStore((s) => s.hydrated);
	const language = useVpnStore((s) => s.language);
	const status = useVpnStore((s) => s.status);
	const selectedServerId = useVpnStore((s) => s.selectedServerId);
	const protocol = useVpnStore((s) => s.protocol);
	const sessionStartedAt = useVpnStore((s) => s.sessionStartedAt);
	const bytesUp = useVpnStore((s) => s.bytesUp);
	const bytesDown = useVpnStore((s) => s.bytesDown);
	const rateUp = useVpnStore((s) => s.rateUp);
	const rateDown = useVpnStore((s) => s.rateDown);
	const virtualIp = useVpnStore((s) => s.virtualIp);
	const hasSeenIntro = useVpnStore((s) => s.hasSeenIntro);
	const toggleConnection = useVpnStore((s) => s.toggleConnection);
	const setHydrated = useVpnStore((s) => s.setHydrated);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useVpnStore.persist.rehydrate()).then(() => setHydrated());
	}, [setHydrated]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		document.documentElement.lang = language === "fa" ? "fa" : "en";
		document.documentElement.dir = language === "fa" ? "rtl" : "ltr";
	}, [hydrated, language]);
	(0, import_react.useEffect)(() => {
		if (status !== "connected") return;
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, [status]);
	const server = getServer(selectedServerId);
	const elapsed = status === "connected" && sessionStartedAt ? Math.max(0, Math.floor((now - sessionStartedAt) / 1e3)) : 0;
	const statusLabel = status === "connected" ? t(language, "connected") : status === "connecting" ? t(language, "connecting") : t(language, "disconnected");
	const hint = status === "connected" ? t(language, "tapToDisconnect") : status === "connecting" ? t(language, "connectingHint") : t(language, "tapToConnect");
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-full flex-1 flex-col bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "m-auto size-10 rounded-full border border-border" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-full flex-1 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						onClick: () => setPanel("settings"),
						"aria-label": t(language, "settingsTitle"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-wide",
							children: t(language, "appName")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: t(language, "tagline")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						onClick: () => setPanel("logs"),
						"aria-label": t(language, "logsTitle"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col px-5 pb-5 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col items-center justify-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("rounded-full border border-border px-3 py-1 text-xs", status === "connected" && "border-connected/40 text-connected", status === "connecting" && "text-accent", status === "disconnected" && "text-muted"),
								children: statusLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectOrb, {
									status,
									onToggle: toggleConnection,
									label: hint
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-center text-sm text-muted",
								children: hint
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: t(language, "download"),
								value: formatMbps(rateDown),
								sub: formatBytes(bytesDown)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: t(language, "session"),
								value: formatDuration(elapsed),
								sub: virtualIp ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: t(language, "upload"),
								value: formatMbps(rateUp),
								sub: formatBytes(bytesUp)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setPanel("locations"),
						className: "mt-3 flex w-full items-center gap-3 rounded-2xl border border-border bg-surface p-3 text-start transition-colors duration-150 hover:bg-elevated",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-lg bg-elevated text-xs font-medium tracking-wide text-accent",
								children: server.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate text-sm font-medium",
									children: [t(language, server.cityKey), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: [" · ", t(language, server.countryKey)]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 block text-xs text-muted",
									children: [protocolLabel(language, protocol), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [
											" · ",
											server.ping,
											t(language, "ms")
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 shrink-0 text-subtle rtl:rotate-0 ltr:rotate-180" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 pt-3 text-center text-xs leading-normal text-subtle",
						children: t(language, "homeNote")
					})
				]
			}),
			panel === "locations" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationsPanel, { onBack: () => setPanel("none") }) : null,
			panel === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, { onBack: () => setPanel("none") }) : null,
			panel === "logs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogsPanel, { onBack: () => setPanel("none") }) : null,
			!hasSeenIntro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroSheet, {}) : null
		]
	});
}
function Stat({ label, value, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-surface px-2 py-3 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm font-medium tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate text-xs text-subtle tabular-nums",
				children: sub
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "stage",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "phone",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {})
		})
	});
}
//#endregion
export { Home as component };
