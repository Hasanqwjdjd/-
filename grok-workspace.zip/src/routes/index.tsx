import { createFileRoute } from "@tanstack/react-router";
import { HomeView } from "@/components/vpn/home-view";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="stage">
      <div className="phone">
        <HomeView />
      </div>
    </main>
  );
}
