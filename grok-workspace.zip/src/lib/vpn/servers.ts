import type { Server } from "./types";

export const SERVERS: Server[] = [
  { id: "auto", cityKey: "cityAuto", countryKey: "countryAuto", code: "AUTO", ping: 22, load: 18, ipPrefix: "185.230" },
  { id: "de-fra", cityKey: "cityFra", countryKey: "countryDe", code: "DE", ping: 28, load: 24, ipPrefix: "185.244" },
  { id: "nl-ams", cityKey: "cityAms", countryKey: "countryNl", code: "NL", ping: 31, load: 21, ipPrefix: "45.139" },
  { id: "tr-ist", cityKey: "cityIst", countryKey: "countryTr", code: "TR", ping: 36, load: 33, ipPrefix: "77.92" },
  { id: "ae-dxb", cityKey: "cityDxb", countryKey: "countryAe", code: "AE", ping: 42, load: 29, ipPrefix: "94.205" },
  { id: "se-sto", cityKey: "citySto", countryKey: "countrySe", code: "SE", ping: 39, load: 16, ipPrefix: "185.213" },
  { id: "gb-lon", cityKey: "cityLon", countryKey: "countryGb", code: "GB", ping: 44, load: 38, ipPrefix: "51.89" },
  { id: "fr-par", cityKey: "cityPar", countryKey: "countryFr", code: "FR", ping: 41, load: 27, ipPrefix: "51.158" },
  { id: "us-nyc", cityKey: "cityNyc", countryKey: "countryUs", code: "US", ping: 78, load: 44, ipPrefix: "104.21" },
  { id: "ca-tor", cityKey: "cityTor", countryKey: "countryCa", code: "CA", ping: 82, load: 31, ipPrefix: "142.147" },
  { id: "jp-tyo", cityKey: "cityTyo", countryKey: "countryJp", code: "JP", ping: 91, load: 22, ipPrefix: "103.137" },
  { id: "sg-sin", cityKey: "citySin", countryKey: "countrySg", code: "SG", ping: 88, load: 19, ipPrefix: "103.28" },
];

export function getServer(id: string): Server {
  return SERVERS.find((s) => s.id === id) ?? SERVERS[0]!;
}

export function pickFastest(): Server {
  return SERVERS.filter((s) => s.id !== "auto").reduce((best, cur) =>
    cur.ping < best.ping ? cur : best,
  );
}

export function allocateVirtualIp(prefix: string): string {
  const a = 12 + Math.floor(Math.random() * 200);
  const b = 4 + Math.floor(Math.random() * 250);
  return `${prefix}.${a}.${b}`;
}
