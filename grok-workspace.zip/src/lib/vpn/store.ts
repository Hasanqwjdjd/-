import { create } from "zustand";
import { persist } from "zustand/middleware";
import { allocateVirtualIp, getServer, pickFastest } from "./servers";
import type { ConnectionStatus, Language, LogLine, ProtocolId } from "./types";

type VpnState = {
  status: ConnectionStatus;
  selectedServerId: string;
  protocol: ProtocolId;
  autoReconnect: boolean;
  killSwitch: boolean;
  language: Language;
  sessionStartedAt: number | null;
  bytesUp: number;
  bytesDown: number;
  rateUp: number;
  rateDown: number;
  virtualIp: string | null;
  logs: LogLine[];
  hasSeenIntro: boolean;
  hydrated: boolean;
  setHydrated: () => void;
  setLanguage: (language: Language) => void;
  setProtocol: (protocol: ProtocolId) => void;
  setSelectedServer: (id: string) => void;
  setAutoReconnect: (value: boolean) => void;
  setKillSwitch: (value: boolean) => void;
  setHasSeenIntro: () => void;
  toggleConnection: () => void;
  disconnect: (reason?: "cancel" | "stop") => void;
  clearLogs: () => void;
};

let connectGen = 0;
const timeouts: number[] = [];
let tickId: number | null = null;

function clearTimeouts() {
  for (const id of timeouts) window.clearTimeout(id);
  timeouts.length = 0;
}

function stopTick() {
  if (tickId != null) {
    window.clearInterval(tickId);
    tickId = null;
  }
}

function pushLog(textKey: LogLine["textKey"], detail?: string): LogLine {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    at: Date.now(),
    textKey,
    detail,
  };
}

export const useVpnStore = create<VpnState>()(
  persist(
    (set, get) => ({
      status: "disconnected",
      selectedServerId: "auto",
      protocol: "wireguard",
      autoReconnect: true,
      killSwitch: false,
      language: "fa",
      sessionStartedAt: null,
      bytesUp: 0,
      bytesDown: 0,
      rateUp: 0,
      rateDown: 0,
      virtualIp: null,
      logs: [],
      hasSeenIntro: false,
      hydrated: false,
      setHydrated: () => set({ hydrated: true }),
      setLanguage: (language) => set({ language }),
      setProtocol: (protocol) => set({ protocol }),
      setSelectedServer: (id) => {
        const { status } = get();
        set({ selectedServerId: id });
        if (status === "connected") get().disconnect("stop");
      },
      setAutoReconnect: (value) => set({ autoReconnect: value }),
      setKillSwitch: (value) => set({ killSwitch: value }),
      setHasSeenIntro: () => set({ hasSeenIntro: true }),
      clearLogs: () => set({ logs: [] }),
      disconnect: (reason = "stop") => {
        connectGen += 1;
        clearTimeouts();
        stopTick();
        const key = reason === "cancel" ? "logCancel" : "logDown";
        set((s) => ({
          status: "disconnected",
          sessionStartedAt: null,
          bytesUp: 0,
          bytesDown: 0,
          rateUp: 0,
          rateDown: 0,
          virtualIp: null,
          logs: [pushLog(key), ...s.logs].slice(0, 80),
        }));
      },
      toggleConnection: () => {
        const { status } = get();
        if (status === "connecting") {
          get().disconnect("cancel");
          return;
        }
        if (status === "connected") {
          get().disconnect("stop");
          return;
        }

        const gen = ++connectGen;
        const server = getServer(get().selectedServerId);
        const endpoint = server.id === "auto" ? pickFastest() : server;
        const protocol = get().protocol;

        set((s) => ({
          status: "connecting",
          logs: [pushLog("logResolve", endpoint.code), ...s.logs].slice(0, 80),
        }));

        const steps: Array<{ delay: number; apply: () => void }> = [
          {
            delay: 520,
            apply: () =>
              set((s) => ({
                logs: [pushLog("logChannel"), ...s.logs].slice(0, 80),
              })),
          },
          {
            delay: 1100,
            apply: () =>
              set((s) => ({
                logs: [pushLog("logHandshake", protocol), ...s.logs].slice(0, 80),
              })),
          },
          {
            delay: 1680,
            apply: () =>
              set((s) => ({
                logs: [pushLog("logAddress"), ...s.logs].slice(0, 80),
              })),
          },
          {
            delay: 2280,
            apply: () => {
              const ip = allocateVirtualIp(endpoint.ipPrefix);
              set((s) => ({
                status: "connected",
                sessionStartedAt: Date.now(),
                virtualIp: ip,
                logs: [
                  pushLog("logUp", ip),
                  pushLog("logRoute"),
                  ...s.logs,
                ].slice(0, 80),
              }));
              stopTick();
              tickId = window.setInterval(() => {
                if (get().status !== "connected") return;
                const down = 18_000 + Math.random() * 420_000;
                const up = 6_000 + Math.random() * 90_000;
                set((s) => ({
                  bytesDown: s.bytesDown + down,
                  bytesUp: s.bytesUp + up,
                  rateDown: down,
                  rateUp: up,
                }));
              }, 1000);
            },
          },
        ];

        for (const step of steps) {
          const id = window.setTimeout(() => {
            if (connectGen !== gen) return;
            step.apply();
          }, step.delay);
          timeouts.push(id);
        }
      },
    }),
    {
      name: "soren-vpn",
      skipHydration: true,
      partialize: (s) => ({
        selectedServerId: s.selectedServerId,
        protocol: s.protocol,
        autoReconnect: s.autoReconnect,
        killSwitch: s.killSwitch,
        language: s.language,
        hasSeenIntro: s.hasSeenIntro,
      }),
    },
  ),
);
