export type ProtocolId = "wireguard" | "openvpn" | "ikev2";
export type ConnectionStatus = "disconnected" | "connecting" | "connected";
export type Language = "fa" | "en";
export type Panel = "none" | "locations" | "settings" | "logs";

export type Server = {
  id: string;
  cityKey: string;
  countryKey: string;
  code: string;
  ping: number;
  load: number;
  ipPrefix: string;
};

export type LogLine = {
  id: string;
  at: number;
  textKey:
    | "logResolve"
    | "logChannel"
    | "logHandshake"
    | "logAddress"
    | "logRoute"
    | "logUp"
    | "logDown"
    | "logCancel";
  detail?: string;
};
