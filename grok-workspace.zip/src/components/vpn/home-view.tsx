import { useEffect, useState } from "react";
import { ChevronLeft, ScrollText, Settings2 } from "lucide-react";
import { ConnectOrb } from "./connect-orb";
import { IntroSheet } from "./intro-sheet";
import { LocationsPanel } from "./locations-panel";
import { LogsPanel } from "./logs-panel";
import { SettingsPanel } from "./settings-panel";
import { Button } from "@/components/ui/button";
import { cn, formatBytes, formatDuration, formatMbps } from "@/lib/utils";
import { protocolLabel, t, type CopyKey } from "@/lib/vpn/copy";
import { getServer } from "@/lib/vpn/servers";
import { useVpnStore } from "@/lib/vpn/store";
import type { Panel } from "@/lib/vpn/types";

export function HomeView() {
  const [panel, setPanel] = useState<Panel>("none");
  const [now, setNow] = useState(Date.now());

  const hydrated = useVpnStore((s) => s.hydrated);
  const language = useVpnStore((s) => s.language);
  const status = useVpnStore((s) => s.status);
  const selectedServerId = useVpnStore((s) => s.selectedServerId);
  const protocol = useVpnStore((s) => s.protocol);
  const sessionStartedAt = useVpnStore((s) => s.sessionStartedAt);
  const bytesUp = useVpnStore((s) => s.bytesUp);
  const bytesDown = useVpnStore((s) => s.bytesDown);
  const rateUp = useVpnStore((s) => s.rateUp);
  const rateDown = useVpnStore((s) => s.rateDown);
  const virtualIp = useVpnStore((s) => s.virtualIp);
  const hasSeenIntro = useVpnStore((s) => s.hasSeenIntro);
  const toggleConnection = useVpnStore((s) => s.toggleConnection);
  const setHydrated = useVpnStore((s) => s.setHydrated);

  useEffect(() => {
    const done = Promise.resolve(useVpnStore.persist.rehydrate());
    void done.then(() => setHydrated());
  }, [setHydrated]);

  useEffect(() => {
    if (!hydrated) return;
    document.documentElement.lang = language === "fa" ? "fa" : "en";
    document.documentElement.dir = language === "fa" ? "rtl" : "ltr";
  }, [hydrated, language]);

  useEffect(() => {
    if (status !== "connected") return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [status]);

  const server = getServer(selectedServerId);
  const elapsed =
    status === "connected" && sessionStartedAt
      ? Math.max(0, Math.floor((now - sessionStartedAt) / 1000))
      : 0;

  const statusLabel =
    status === "connected"
      ? t(language, "connected")
      : status === "connecting"
        ? t(language, "connecting")
        : t(language, "disconnected");

  const hint =
    status === "connected"
      ? t(language, "tapToDisconnect")
      : status === "connecting"
        ? t(language, "connectingHint")
        : t(language, "tapToConnect");

  if (!hydrated) {
    return (
      <div className="flex min-h-full flex-1 flex-col bg-bg">
        <div className="m-auto size-10 rounded-full border border-border" />
      </div>
    );
  }

  return (
    <div className="relative flex min-h-full flex-1 flex-col bg-bg">
      <header className="flex items-center justify-between px-3 pt-3">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => setPanel("settings")}
          aria-label={t(language, "settingsTitle")}
        >
          <Settings2 className="size-5" />
        </Button>
        <div className="text-center">
          <p className="text-sm font-medium tracking-wide">{t(language, "appName")}</p>
          <p className="text-xs text-muted">{t(language, "tagline")}</p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => setPanel("logs")}
          aria-label={t(language, "logsTitle")}
        >
          <ScrollText className="size-5" />
        </Button>
      </header>

      <div className="flex flex-1 flex-col px-5 pb-5 pt-2">
        <div className="flex flex-1 flex-col items-center justify-center">
          <p className="mb-3 max-w-[18rem] text-center text-lg font-medium leading-snug text-fg">
            {t(language, "slogan")}
          </p>
          <span
            className={cn(
              "rounded-full border border-border px-3 py-1 text-xs",
              status === "connected" && "border-connected/40 text-connected",
              status === "connecting" && "text-accent",
              status === "disconnected" && "text-muted",
            )}
          >
            {statusLabel}
          </span>
          <div className="mt-6">
            <ConnectOrb status={status} onToggle={toggleConnection} label={hint} />
          </div>
          <p className="mt-4 text-center text-sm text-muted">{hint}</p>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <Stat label={t(language, "download")} value={formatMbps(rateDown)} sub={formatBytes(bytesDown)} />
          <Stat
            label={t(language, "session")}
            value={formatDuration(elapsed)}
            sub={virtualIp ?? "—"}
          />
          <Stat label={t(language, "upload")} value={formatMbps(rateUp)} sub={formatBytes(bytesUp)} />
        </div>

        <button
          type="button"
          onClick={() => setPanel("locations")}
          className="mt-3 flex w-full items-center gap-3 rounded-2xl border border-border bg-surface p-3 text-start transition-colors duration-150 hover:bg-elevated"
        >
          <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-elevated text-xs font-medium tracking-wide text-accent">
            {server.code}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">
              {t(language, server.cityKey as CopyKey)}
              <span className="text-muted"> · {t(language, server.countryKey as CopyKey)}</span>
            </span>
            <span className="mt-0.5 block text-xs text-muted">
              {protocolLabel(language, protocol)}
              <span className="tabular-nums"> · {server.ping}{t(language, "ms")}</span>
            </span>
          </span>
          <ChevronLeft className="size-4 shrink-0 text-subtle rtl:rotate-0 ltr:rotate-180" />
        </button>

        <p className="px-1 pt-3 text-center text-xs leading-normal text-subtle">
          {t(language, "homeNote")}
        </p>
      </div>

      {panel === "locations" ? <LocationsPanel onBack={() => setPanel("none")} /> : null}
      {panel === "settings" ? <SettingsPanel onBack={() => setPanel("none")} /> : null}
      {panel === "logs" ? <LogsPanel onBack={() => setPanel("none")} /> : null}
      {!hasSeenIntro ? <IntroSheet /> : null}
    </div>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-2 py-3 text-center">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 text-sm font-medium tabular-nums">{value}</p>
      <p className="mt-0.5 truncate text-xs text-subtle tabular-nums">{sub}</p>
    </div>
  );
}
