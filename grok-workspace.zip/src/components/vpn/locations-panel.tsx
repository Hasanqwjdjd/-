import { Check } from "lucide-react";
import { PanelHeader } from "./panel-header";
import { cn } from "@/lib/utils";
import { t, type CopyKey } from "@/lib/vpn/copy";
import { SERVERS } from "@/lib/vpn/servers";
import { useVpnStore } from "@/lib/vpn/store";

type Props = {
  onBack: () => void;
};

export function LocationsPanel({ onBack }: Props) {
  const language = useVpnStore((s) => s.language);
  const selected = useVpnStore((s) => s.selectedServerId);
  const setSelectedServer = useVpnStore((s) => s.setSelectedServer);

  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-bg panel-enter">
      <PanelHeader
        title={t(language, "locationsTitle")}
        subtitle={t(language, "locationsSub")}
        onBack={onBack}
        backLabel={t(language, "back")}
      />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">
        <ul className="flex flex-col gap-2">
          {SERVERS.map((server) => {
            const active = server.id === selected;
            return (
              <li key={server.id}>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedServer(server.id);
                    onBack();
                  }}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl border px-3 py-3 text-start",
                    "transition-[background-color,border-color] duration-150 ease-out",
                    active
                      ? "border-accent/40 bg-elevated"
                      : "border-border bg-surface hover:bg-elevated",
                  )}
                >
                  <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-elevated text-xs font-medium tracking-wide text-accent">
                    {server.code}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">
                      {t(language, server.cityKey as CopyKey)}
                    </span>
                    <span className="block truncate text-sm text-muted">
                      {t(language, server.countryKey as CopyKey)}
                    </span>
                  </span>
                  <span className="flex shrink-0 flex-col items-end gap-1">
                    <span className="tabular-nums text-sm text-fg">
                      {server.ping}
                      {t(language, "ms")}
                    </span>
                    <span className="text-xs text-muted tabular-nums">
                      {t(language, "load")} {server.load}%
                    </span>
                  </span>
                  {active ? (
                    <Check className="size-4 shrink-0 text-connected" strokeWidth={2} />
                  ) : (
                    <span className="size-4 shrink-0" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
