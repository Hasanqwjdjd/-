import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

type Props = {
  title: string;
  subtitle?: string;
  onBack: () => void;
  backLabel: string;
};

export function PanelHeader({ title, subtitle, onBack, backLabel }: Props) {
  return (
    <header className="flex items-center gap-3 px-4 pt-4 pb-3">
      <Button
        type="button"
        variant="ghost"
        size="icon"
        onClick={onBack}
        aria-label={backLabel}
        className="shrink-0"
      >
        <ChevronRight className="size-5 rtl:rotate-0 ltr:rotate-180" />
      </Button>
      <div className="min-w-0">
        <h2 className="text-base font-medium leading-snug">{title}</h2>
        {subtitle ? (
          <p className="text-sm text-muted leading-snug">{subtitle}</p>
        ) : null}
      </div>
    </header>
  );
}
