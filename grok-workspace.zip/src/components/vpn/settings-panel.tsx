import { PanelHeader } from "./panel-header";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { protocolLabel, t } from "@/lib/vpn/copy";
import { useVpnStore } from "@/lib/vpn/store";
import type { ProtocolId } from "@/lib/vpn/types";

const PROTOCOLS: ProtocolId[] = ["wireguard", "openvpn", "ikev2"];

type Props = {
  onBack: () => void;
};

export function SettingsPanel({ onBack }: Props) {
  const language = useVpnStore((s) => s.language);
  const protocol = useVpnStore((s) => s.protocol);
  const autoReconnect = useVpnStore((s) => s.autoReconnect);
  const killSwitch = useVpnStore((s) => s.killSwitch);
  const setLanguage = useVpnStore((s) => s.setLanguage);
  const setProtocol = useVpnStore((s) => s.setProtocol);
  const setAutoReconnect = useVpnStore((s) => s.setAutoReconnect);
  const setKillSwitch = useVpnStore((s) => s.setKillSwitch);

  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-bg panel-enter">
      <PanelHeader
        title={t(language, "settingsTitle")}
        onBack={onBack}
        backLabel={t(language, "back")}
      />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-8">
        <section className="rounded-2xl border border-border bg-surface p-4">
          <div className="flex items-center justify-between gap-4 py-2">
            <div className="min-w-0">
              <p className="text-sm font-medium">{t(language, "autoReconnect")}</p>
              <p className="text-sm text-muted">{t(language, "autoReconnectHint")}</p>
            </div>
            <Switch
              checked={autoReconnect}
              onCheckedChange={setAutoReconnect}
              aria-label={t(language, "autoReconnect")}
            />
          </div>
          <div className="my-3 h-px bg-border" />
          <div className="flex items-center justify-between gap-4 py-2">
            <div className="min-w-0">
              <p className="text-sm font-medium">{t(language, "killSwitch")}</p>
              <p className="text-sm text-muted">{t(language, "killSwitchHint")}</p>
            </div>
            <Switch
              checked={killSwitch}
              onCheckedChange={setKillSwitch}
              aria-label={t(language, "killSwitch")}
            />
          </div>
        </section>

        <p className="mt-6 mb-2 px-1 text-xs font-medium tracking-wide text-muted">
          {t(language, "protocol")}
        </p>
        <div className="grid grid-cols-3 gap-2 rounded-2xl border border-border bg-surface p-2">
          {PROTOCOLS.map((id) => {
            const active = protocol === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setProtocol(id)}
                className={cn(
                  "h-10 rounded-lg text-sm font-medium transition-colors duration-150",
                  active ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
                )}
              >
                {protocolLabel(language, id)}
              </button>
            );
          })}
        </div>

        <p className="mt-6 mb-2 px-1 text-xs font-medium tracking-wide text-muted">
          {t(language, "language")}
        </p>
        <div className="grid grid-cols-2 gap-2 rounded-2xl border border-border bg-surface p-2">
          <button
            type="button"
            onClick={() => setLanguage("fa")}
            className={cn(
              "h-10 rounded-lg text-sm font-medium transition-colors duration-150",
              language === "fa" ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {t(language, "languageFa")}
          </button>
          <button
            type="button"
            onClick={() => setLanguage("en")}
            className={cn(
              "h-10 rounded-lg text-sm font-medium transition-colors duration-150",
              language === "en" ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {t(language, "languageEn")}
          </button>
        </div>

        <section className="mt-6 rounded-2xl border border-border bg-surface p-4">
          <h3 className="text-sm font-medium">{t(language, "about")}</h3>
          <p className="mt-2 text-sm leading-normal text-muted">{t(language, "aboutBody")}</p>
        </section>
      </div>
    </div>
  );
}
