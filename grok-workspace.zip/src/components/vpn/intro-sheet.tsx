import { Button } from "@/components/ui/button";
import { t } from "@/lib/vpn/copy";
import { useVpnStore } from "@/lib/vpn/store";

export function IntroSheet() {
  const language = useVpnStore((s) => s.language);
  const setHasSeenIntro = useVpnStore((s) => s.setHasSeenIntro);

  return (
    <div className="absolute inset-0 z-30 flex items-end bg-bg/70 panel-enter">
      <div className="w-full rounded-t-2xl border border-border bg-surface p-5 pb-8">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-border" />
        <h2 className="text-lg font-medium leading-snug">{t(language, "introTitle")}</h2>
        <p className="mt-2 text-sm leading-normal text-muted">{t(language, "introBody")}</p>
        <Button type="button" className="mt-5 w-full" onClick={setHasSeenIntro}>
          {t(language, "introCta")}
        </Button>
      </div>
    </div>
  );
}
