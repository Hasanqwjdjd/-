import { PanelHeader } from "./panel-header";
import { Button } from "@/components/ui/button";
import { t } from "@/lib/vpn/copy";
import { useVpnStore } from "@/lib/vpn/store";

type Props = {
  onBack: () => void;
};

export function LogsPanel({ onBack }: Props) {
  const language = useVpnStore((s) => s.language);
  const logs = useVpnStore((s) => s.logs);
  const clearLogs = useVpnStore((s) => s.clearLogs);

  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-bg panel-enter">
      <PanelHeader
        title={t(language, "logsTitle")}
        onBack={onBack}
        backLabel={t(language, "back")}
      />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">
        {logs.length === 0 ? (
          <p className="px-1 py-8 text-sm text-muted">{t(language, "logsEmpty")}</p>
        ) : (
          <ol className="flex flex-col gap-2">
            {logs.map((line) => {
              const time = new Date(line.at).toLocaleTimeString(
                language === "fa" ? "fa-IR" : "en-GB",
                { hour: "2-digit", minute: "2-digit", second: "2-digit" },
              );
              return (
                <li
                  key={line.id}
                  className="rounded-xl border border-border bg-surface px-3 py-2.5"
                >
                  <p className="text-xs tabular-nums text-muted">{time}</p>
                  <p className="mt-1 text-sm">
                    {t(language, line.textKey)}
                    {line.detail ? (
                      <span className="text-muted"> · {line.detail}</span>
                    ) : null}
                  </p>
                </li>
              );
            })}
          </ol>
        )}
        {logs.length > 0 ? (
          <div className="mt-4">
            <Button type="button" variant="outline" className="w-full" onClick={clearLogs}>
              {t(language, "clearLogs")}
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  );
}
