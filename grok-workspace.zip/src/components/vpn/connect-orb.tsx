import { Power } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ConnectionStatus } from "@/lib/vpn/types";

type Props = {
  status: ConnectionStatus;
  onToggle: () => void;
  label: string;
};

export function ConnectOrb({ status, onToggle, label }: Props) {
  const live = status === "connected";
  const busy = status === "connecting";

  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={label}
      aria-pressed={live}
      className={cn(
        "relative mx-auto grid size-44 place-items-center rounded-full outline-none",
        "transition-transform duration-150 ease-out active:scale-[0.96]",
        "focus-visible:ring-2 focus-visible:ring-accent/70",
      )}
    >
      <svg
        viewBox="0 0 176 176"
        className={cn("absolute inset-0 size-full", live && "orb-live")}
        aria-hidden="true"
      >
        <circle
          cx="88"
          cy="88"
          r="82"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          className="text-border"
        />
        <circle
          cx="88"
          cy="88"
          r="70"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          className={cn(live ? "text-connected/40" : "text-border")}
        />
        <circle
          cx="88"
          cy="88"
          r="70"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={busy ? "44 400" : live ? "440 0" : "0 440"}
          className={cn(
            "text-accent transition-[stroke-dasharray] duration-500",
            live && "text-connected",
            busy && "orb-spin text-accent",
          )}
        />
        {busy ? (
          <circle
            cx="88"
            cy="88"
            r="58"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
            className="orb-pulse text-accent/50"
          />
        ) : null}
      </svg>
      <span
        className={cn(
          "relative grid size-24 place-items-center rounded-full border border-border bg-surface",
          "transition-colors duration-200",
          live && "border-connected/40 bg-elevated",
        )}
      >
        <Power
          className={cn(
            "size-8 transition-colors duration-200",
            live ? "text-connected" : "text-fg",
            busy && "opacity-70",
          )}
          strokeWidth={1.75}
        />
      </span>
    </button>
  );
}
